import time
from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, template_folder="templates")
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://louise:my_password@mysql:3306/users'
db = SQLAlchemy(app)


# La classe User qui hérite de db.Model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    family_name = db.Column(db.String(80), unique=False, nullable=False)
    first_name = db.Column(db.String(80), unique=False, nullable=False)

# Le Uri qui permet d'afficher les utilisateurs
@app.route('/')
def question5():
    users = User.query.all()
    return render_template('question5.html', users=users)

# Le Uri qui permet d'ajouter un utilisateur
@app.route('/add_user', methods=['POST'])
def add_user():
    if request.method == 'POST':
        family_name = request.form['family_name']
        first_name = request.form['first_name']
        new_user = User(family_name=family_name, first_name=first_name)
        db.session.add(new_user)
        db.session.commit()
    return redirect('/')

## Questions 1, 2 et 3 déplacées au uri /questions123
@app.route('/questions123')
def questions123():
    return render_template('questions123.html')

if __name__ == "__main__":
    #time.sleep(10)
    with app.app_context():
        while True:
            try:
                db.create_all()
                break
            except Exception as e:
                print(e)
                time.sleep(2)
        app.run(debug=True, host='0.0.0.0', port=5000)